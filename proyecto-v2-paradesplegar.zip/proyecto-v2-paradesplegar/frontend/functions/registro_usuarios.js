
const form = document.getElementById('registroForm')
form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const rut = document.getElementById("rut").value.trim();
    const nombre = document.getElementById("nombre").value.trim();
    const apellido = document.getElementById("apellido").value.trim();
    const direccion = document.getElementById("direccion").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();
    const confirmPassword = document.getElementById("confirmPassword").value.trim();

    if (!rut || !nombre || !apellido || !direccion || !email || !password || !confirmPassword) {
        alert("Todos los campos son obligatorios");
        return;
    }

    const validarRut =  /^[0-9]{8}[0-9K]$/;//Permite que los 8 primeros digitos puedan ser del 0 al 9, y el ultimo digito pueda ser del 0 al 9 o K

    if (!validarRut.test(rut.toUpperCase())) {
        alert("RUT Inválido");
        return;
    }

    const validarLetrasEsp = /^[a-zA-ZÀ-ÿ\u00f1\u00d1\s]+$/;//Permite solo letras y letras especiales con tilde o Ññ

    if (!validarLetrasEsp.test(nombre)) {
        alert("El nombre solo puede contener letras");
        return;
    }

     if (!validarLetrasEsp.test(apellido)) {
        alert("El apellido solo puede contener letras");
        return;
    }

    const validarEmail = /^[a-zA-Z0-9]+@[a-zA-Z]+\.[a-zA-Z]{2,}$/;

    if (!validarEmail.test(email)) {
        alert("Correo inválido, formato correcto usuario@gmail.com");
        return;
    }


    if (!email.endsWith("@gmail.com") && !email.endsWith("@outlook.com")) {
        alert("El correo debe ser válido, debe terminar en @gmail.com o @outlook.com");
        return;
    }

    if (password.length < 8) {
        alert("La contraseña debe tener al menos 8 caracteres.");
        return;  // Detiene la ejecución si la contraseña es demasiado corta
    }

    if (password !== confirmPassword) {
        alert("Las contraseñas no coinciden");
        return;
    }

    try {
        const response = await fetch("http://localhost:8888/registrar_usuario", {
            method: "POST",
            headers: { "Content-Type": "application/json" }, 
            body: JSON.stringify({ rut, nombre, apellido, direccion, email, password }) 
        });

            if (!response.ok) {
            const errorJson = await response.json(); //response.json() convierte el cuerpo de la respuesta HTTP en un objeto y se guarda en erroJson
            throw new Error(errorJson.message || "Error en el servidor");
            }

        const data = await response.json();

        if (data.success) {
            alert(`¡${data.message}!, Ya puedes iniciar sesión`); 
            window.location.href = "login.html"; // Redirige al login
        } else {
            alert(data.message);                                
        }
    }catch (error) {
        alert(`Hubo un problema con el registro: ${error.message} Intenta de nuevo.`);
    }
});
