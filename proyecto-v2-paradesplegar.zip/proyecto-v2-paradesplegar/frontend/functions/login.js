
const errorDiv = document.getElementById('error');
const form = document.getElementById('loginForm')
form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    if (!email || !password) {
        errorDiv.textContent = "Todos los campos son obligatorios.";
        errorDiv.style.display = "block";
        errorDiv.style.color = "red";
        return;
    }
    

    //  fetch al backend
    try {
        const response = await fetch('http://localhost:8888/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

            if (!response.ok) {
            const errorJson = await response.json(); //response.json() convierte el cuerpo de la respuesta HTTP en un objeto y se guarda en erroJson
            throw new Error(errorJson.message || "Error en el servidor");
        }

        const data = await response.json();

        if (data.success) {
        alert(`Hola ${data.nombre}, ${data.message}`);  // ejemplo: Hola Javier
        window.location.href = "index.html"; // redirigir a inicio
        } else {
        alert(data.message); // ejemplo: "Tu cuenta está inactiva"
        }

    }catch (error) {
        alert(`Error al iniciar sesión: ${error.message}. Intenta de nuevo.`);
    }
});
    
