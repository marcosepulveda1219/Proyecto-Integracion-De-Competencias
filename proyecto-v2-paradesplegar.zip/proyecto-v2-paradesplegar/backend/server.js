const express = require('express');
const path = require('path');
const mysql = require('mysql2/promise');
const app = express();
const PORT = 8888;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, '..', 'frontend')));

(async () => {
  try {
    const pool = await mysql.createPool({
      host: 'localhost',
      user: 'root',
      password: 'marco001234',
      database: 'localcomidarapida',
      waitForConnections: true,
      connectionLimit: 10, //Cantidad de conexiones simultaneas para que no se sature la app al tener un alto tráfico
      queueLimit: 0
    });

    console.log('Conectado a MySQL');

    app.get('/', (req, res) => {
      res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html'));
    });

    //Registro de usuarios
    app.post('/registrar_usuario', async (req, res) => {
      const { rut, nombre, apellido, direccion, email, password } = req.body;
      console.log(`Datos recibidos: RUT:${rut}, Nombre:${nombre}, Apellido:${apellido},
                   Direccion:${direccion}, Email:${email}, Password:${password}`) //Depuración

      try {
        const[rows] = await pool.execute(
          'SELECT id_usuario FROM usuarios WHERE rut = ? OR email = ?',
          [rut, email]
        );
        //Preguntamos si el usuario ya existe
        if(rows.length > 0){
          return res.status(400).json({
            succes: false,
            message: 'El usuario ya existe con ese RUT o Correo'
          })
        }
        //Insertamos el usuario
        const [result] = await pool.execute(
          'INSERT INTO usuarios (rut, nombre, apellido, direccion, email, password) VALUES (?, ?, ?, ?, ?, ?)',
          [rut, nombre, apellido, direccion, email, password]
        );
        //Respuesta
        res.json({
          success: true,
          message: 'Usuario registrado correctamente',
          id: result.insertId,
          nombre
        });
        console.log(`\n Se registró un nuevo usuario: ID:${result.insertId} RUT:${rut}, Nombre:${nombre}, Apellido:${apellido},
                   Direccion:${direccion}, Email:${email}, Password:${password}`)
      } catch (err) {
        console.error('Error al registrar el usuario:', err);
        res.status(500).json({ success: false, error: 'Error al registrar usuario' });
      }
    });



     //Registro de Administradores
    app.post('/registrar_administrador', async (req, res) => {
      const { rut, nombre, apellido, direccion, email, password} = req.body;
      console.log(`Datos recibidos: RUT:${rut}, Nombre:${nombre}, Apellido:${apellido},
                   Direccion:${direccion}, Email:${email}, Password:${password}`) //Depuración

      try {
        const[rows] = await pool.execute(
          'SELECT id_administrador FROM administrador WHERE rut = ? OR email = ?',
          [rut, email]
        );
        //Preguntamos si el usuario ya existe
        if(rows.length > 0){
          return res.status(400).json({
            succes: false,
            message: 'El usuario ya existe con ese RUT o Correo'
          })
        }

         // Obtener id_pedido por defecto de la tabla local
        const [localRows] = await pool.execute('SELECT id_local FROM local ORDER BY id_local ASC LIMIT 1');
        const idLocalDefault = localRows[0].id_local;


        //Insertamos el usuario
        const [result] = await pool.execute(
          'INSERT INTO administrador (id_local, rut, nombre, apellido, direccion, email, password) VALUES (?, ?, ?, ?, ?, ?, ?)',
          [idLocalDefault, rut, nombre, apellido, direccion, email, password]
        );
        //Respuesta
        res.json({
          success: true,
          message: 'Administrador registrado correctamente',
          id: result.insertId,
          nombre
        });
        console.log(`\n Se registró un nuevo Adminstrador: ID:${result.insertId} RUT:${rut}, Nombre:${nombre}, Apellido:${apellido},
                   Direccion:${direccion}, Email:${email}, Password:${password}`)
      } catch (err) {
        console.error('Error al registrar al administrador:', err);
        res.status(500).json({ success: false, error: 'Error al registrar al administrador' });
      }
    });

    //Registro de delivery
    app.post('/registrar_delivery', async (req, res) => {
      const { rut, nombre, apellido, direccion, email, password} = req.body;
      console.log(`Datos recibidos: RUT:${rut}, Nombre:${nombre}, Apellido:${apellido},
                   Direccion:${direccion}, Email:${email}, Password:${password}`) //Depuración

      try {
        const[rows] = await pool.execute(
          'SELECT id_delivery FROM delivery WHERE rut = ? OR email = ?',
          [rut, email]
        );

        //Preguntamos si el usuario ya existe
        if(rows.length > 0){
          return res.status(400).json({
            succes: false,
            message: 'El usuario ya existe con ese RUT o Correo'
          })
        }

         // Obtener id_pedido por defecto de la tabla local
        const [localRows] = await pool.execute('SELECT id_local FROM local ORDER BY id_local ASC LIMIT 1');
        const idLocalDefault = localRows[0].id_local; // a idLocalDefault se le asigna el valor del primer id (id_local)  y único que se encuentra en la tabla local


        //Insertamos el usuario
        const [result] = await pool.execute(
          'INSERT INTO delivery (id_local, rut, nombre, apellido, direccion, email, password) VALUES (?, ?, ?, ?, ?, ?, ?)',
          [idLocalDefault, rut, nombre, apellido, direccion, email, password]
        );
        //Respuesta
        res.json({
          success: true,
          message: 'Delivery registrado correctamente',
          id: result.insertId,
          nombre
        });
        console.log(`\n Se registró un nuevo Delivery: ID:${result.insertId} RUT:${rut}, Nombre:${nombre}, Apellido:${apellido},
                   Direccion:${direccion}, Email:${email}, Password:${password}`)
      } catch (err) {
        console.error('Error al registrar al delivery:', err);
        res.status(500).json({ success: false, error: 'Error al registrar al delivery' });
      }
    });

    //Manejo del login
    app.post('/login', async (req, res) => {
      const { email, password } = req.body; 

      try {
        //[rows] es una lista con los resultados de la consulta sql
        const [rows] = await pool.execute(
          'SELECT id_usuario, nombre, email, password FROM usuarios WHERE email = ?',
          [email]
        );

        if (rows.length === 0) {
          return res.status(401).json({
            success: false,
            message: 'Credenciales inválidas',
          })
        } 
        //como hicimos la busqueda WHERE email = ?
        // rows[0] es el primer y único objeto que se encontró en la consulta y usuario lo almacena
        const usuario = rows[0];
  
        if(usuario.password !== password){
          return res.status(401).json({ success: false,
          message: 'Credenciales inválidas'});
        }

        res.json({
            success: true,
            message: 'Inicio de sesion exitoso', 
            nombre: usuario.nombre});

      } catch (error) {
        console.error('Error en login:', error);
        res.status(500).json({ success: false, message: 'Error en el servidor' });
      }
    });

    app.listen(PORT, () => {
      console.log(`Servidor corriendo en http://localhost:${PORT}`);
    });

  } catch (err) {
    console.error('Error conectando a MySQL:', err);
    process.exit(1);
  }
})();
